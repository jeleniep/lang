#include<stdio.h>
int main(){
  int x;
  x = 4;
  scanf("%d",&x);
  printf("%d\n",x);
}

