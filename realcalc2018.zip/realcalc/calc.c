#include<stdio.h>
int main(){
  int x = 2;
  double y = 1.2;
  y = x*(int)y;
//  scanf("%d",&x);
  printf("%f\n",x+y);
}

